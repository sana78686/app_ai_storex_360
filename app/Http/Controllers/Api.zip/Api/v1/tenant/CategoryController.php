<?php

namespace App\Http\Controllers\Api\v1\Tenant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tenant\Category;

class CategoryController extends Controller
{
    // List all categories
    // public function index()
    // {
    //     $categories = Category::with('children')->get();
    //     return response()->json(['categories' => $categories]);
    // }
public function index()
{
    $categories = Category::whereNull('parent_id')
        ->with('children')
        ->get();

    return response()->json([
        'categories' => $categories
    ]);
}

    // Show a single category
    public function show($id)
    {
        $category = Category::with('children', 'parent')->findOrFail($id);
        return response()->json(['category' => $category]);
    }

    // Create a new category
   public function store(Request $request)
{
    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'parent_id' => 'nullable|exists:categories,id',
    ]);

    // Automatically calculate the level based on the parent
    $level = 0;
    if ($request->parent_id) {
        $parent = Category::findOrFail($request->parent_id);
        $level = $parent->level + 1;
    }

    $category = Category::create(array_merge($validated, ['level' => $level]));

    return response()->json($category, 201);
}

    // Update a category
    public function update(Request $request, $id)
    {
        $category = Category::findOrFail($id);
        $validated = $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'parent_id' => 'nullable|exists:categories,id',
        ]);
        $category->update($validated);
        return response()->json(['category' => $category]);
    }

    // Delete a category
    public function destroy($id)
    {
        $category = Category::findOrFail($id);
        $category->delete();
        return response()->json(['message' => 'Category deleted']);
    }
}
