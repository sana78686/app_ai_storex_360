<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddStripeFieldsToTenantsTable extends Migration
{
    public function up()
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->string('stripe_account_id')->nullable()->index();
            $table->text('stripe_access_token')->nullable();
            $table->text('stripe_refresh_token')->nullable();
            $table->string('stripe_publishable_key')->nullable();
            $table->string('stripe_scope')->nullable();
            $table->timestamp('stripe_connected_at')->nullable();
        });
    }

    public function down()
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->dropColumn([
                'stripe_account_id',
                'stripe_access_token',
                'stripe_refresh_token',
                'stripe_publishable_key',
                'stripe_scope',
                'stripe_connected_at',
            ]);
        });
    }
}
