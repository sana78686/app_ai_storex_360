<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {

        if (!Schema::hasTable('tenants')) {
            Schema::create('tenants', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->json('data')->nullable();

                // Required direct fields
                $table->string('email')->unique();
                $table->string('password')->nullable();

                // Optional extra fields
                $table->string('name')->nullable();
                $table->string('confirmation_token')->nullable();
                $table->timestamp('confirmation_token_expires_at')->nullable();
                $table->string('status')->default('inactive');
                $table->boolean('is_approved')->default(false);
                $table->timestamp('approved_at')->nullable();
                $table->timestamp('trial_ends_at')->nullable();
                $table->string('phone_no')->nullable();
                $table->string('store_name')->nullable();

                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('tenants');
    }
};
