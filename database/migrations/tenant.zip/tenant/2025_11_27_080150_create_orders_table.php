<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_number')->unique();

            // Product info
            $table->unsignedBigInteger('product_id')->nullable(); // Added
            $table->integer('quantity')->default(1); // Added

            // Customer info
            $table->unsignedBigInteger('customer_id')->nullable();
            $table->string('customer_name')->nullable();
            $table->string('customer_email')->nullable();
            $table->string('customer_phone')->nullable();

            // Payment & Stripe fields
            $table->string('payment_status')->default('pending');
            $table->string('stripe_session_id')->nullable(); // Added
            $table->string('stripe_payment_intent_id')->nullable();
            $table->string('stripe_payment_method')->nullable();
            $table->string('currency', 10)->default('usd');

            // Order financials
            $table->decimal('subtotal', 10, 2);
            $table->decimal('tax', 10, 2)->default(0);
            $table->decimal('shipping', 10, 2)->default(0);
            $table->decimal('discount', 10, 2)->default(0);
            $table->decimal('total', 10, 2);

            // Status
            $table->string('order_status')->default('pending');

            // Optional if still needed
            $table->string('status')->nullable(); // If you want to keep it (but recommended to remove from model)

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('orders');
    }
};
