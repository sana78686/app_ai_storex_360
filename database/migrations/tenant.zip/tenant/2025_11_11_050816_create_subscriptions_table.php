<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('subscriptions', function (Blueprint $table) {
            $table->id();
             $table->uuid('tenant_id'); // ✅ Use uuid instead of integer
        $table->foreign('tenant_id')->references('id')->on('tenants')->onDelete('cascade');
            $table->foreignId('plan_id')->constrained()->cascadeOnDelete();

            $table->string('stripe_subscription_id')->nullable();
            $table->string('status')->default('pending'); // active, canceled, past_due, etc.
            $table->timestamp('starts_at')->nullable();
        $table->timestamp('ends_at')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscriptions');
    }
};
