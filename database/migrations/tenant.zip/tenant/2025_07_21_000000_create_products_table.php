<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
      Schema::create('products', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->longText('detailed_description')->nullable();

            // Category
            $table->unsignedBigInteger('category_id')->nullable();
            $table->foreign('category_id')->references('id')->on('categories')->nullOnDelete();

            // Status
            $table->enum('status', ['draft', 'active', 'archived'])->default('draft');

            // Pricing
            $table->decimal('price', 10, 2)->default(0);
            $table->decimal('compare_at_price', 10, 2)->nullable();
            $table->decimal('cost_per_item', 10, 2)->nullable();
            $table->boolean('charge_tax')->default(true);

            // Inventory (base product)
            $table->boolean('inventory_tracked')->default(true);
            $table->integer('quantity')->default(0);

            // Identifiers
            $table->string('sku')->nullable()->index();
            $table->string('barcode')->nullable()->index();

            // Meta
            $table->string('vendor')->nullable();
            $table->string('collection')->nullable();
            $table->string('tags')->nullable();

            // Unit pricing
            $table->decimal('unit_price_total', 10, 2)->nullable();
            $table->string('unit_price_type')->nullable();      // g, ml
            $table->integer('unit_price_base')->nullable();     // 1
            $table->string('unit_price_base_type')->nullable(); // kg, l
            $table->softDeletes();
            $table->timestamps();
        });

    }

    public function down(): void {
        Schema::dropIfExists('products');
    }
};
