<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('product_attribute', function (Blueprint $table) {
            $table->id(); // Optional, or use composite key if needed
            $table->foreignId('product_id')->constrained('products')->onDelete('cascade');
            $table->foreignId('attribute_id')->constrained('attributes')->onDelete('cascade');
            $table->foreignId('attribute_value_id')->constrained('attribute_values')->onDelete('cascade');
            $table->timestamps();

            // Optional unique constraint to prevent duplicates
            $table->unique(['product_id', 'attribute_id', 'attribute_value_id'], 'product_attribute_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_attribute');
    }
};